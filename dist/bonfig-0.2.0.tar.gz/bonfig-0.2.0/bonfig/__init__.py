"""
Bonfig
------
An alternative, more beautiful way to build configs!

"""

from .core import Bonfig, Store

__version__ = "0.2.0"
